package com.example.checked;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.KeyguardManager;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class computer extends AppCompatActivity {
    private EditText idEditText;
    private Button sendButton;
    private ImageButton fingerprintButton;
    private  DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_computer);
//
//        idEditText = findViewById(R.id.idEditText);
//        sendButton = findViewById(R.id.sendButton);
//        fingerprintButton = findViewById(R.id.fingerprintButton);
//
//
//
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("mydata");
//
//        sendButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String id = idEditText.getText().toString();
//                byte[] fingerprintData = authenticateFingerprint();
//                saveUserData(id, fingerprintData);
//            }
//        });
//
//        fingerprintButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                authenticateFingerprint();
//            }
//        });
//    }
//
//    private byte[] authenticateFingerprint() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
//            if (fingerprintManager != null && fingerprintManager.isHardwareDetected() && fingerprintManager.hasEnrolledFingerprints()) {
//                FingerprintManager.AuthenticationCallback authenticationCallback = new FingerprintManager.AuthenticationCallback() {
//                    @Override
//                    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
//                        super.onAuthenticationSucceeded(result);
//                        Toast.makeText(computer.this, "Fingerprint authentication succeeded", Toast.LENGTH_SHORT).show();
//                    }
//
//                    @Override
//                    public void onAuthenticationFailed() {
//                        super.onAuthenticationFailed();
//                        Toast.makeText(computer.this, "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//                    }
//                };
//
//                Cipher cipher = null;
//                try {
//                    cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//                } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//                    e.printStackTrace();
//                }
//
//                FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher);
//
//                fingerprintManager.authenticate(cryptoObject, new CancellationSignal(), 0, authenticationCallback, null);
//            } else {
//                Toast.makeText(computer.this, "Device does not support fingerprint authentication", Toast.LENGTH_SHORT).show();
//            }
//        } else {
//            Toast.makeText(computer.this, "Android version not supported", Toast.LENGTH_SHORT).show();
//        }
//
//        // TODO: Implement fingerprint authentication logic
//        return null;
//    }
//
//
//    private void saveUserData(String id, byte[] fingerprintData) {
//        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("mydata");
//        Users userData = new Users(id, fingerprintData);
//        myRef.push().setValue(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
//            @Override
//            public void onComplete(@NonNull Task<Void> task) {
//                if (task.isSuccessful()) {
//                    Toast.makeText(computer.this, "User data saved successfully", Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(computer.this, "Failed to save user data", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }
}




//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_computer);
//
//        idEditText = findViewById(R.id.idEditText);
//        sendButton = findViewById(R.id.sendButton);
//        fingerprintButton = findViewById(R.id.fingerprintButton);
//
//        sendButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String id = idEditText.getText().toString();
//                byte[] fingerprintData = authenticateFingerprint();
//                saveUserData(id, fingerprintData);
//            }
//        });
//
//        fingerprintButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                authenticateFingerprint();
//            }
//        });
//    }
//
//    private byte[] authenticateFingerprint() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
//            if (fingerprintManager != null && fingerprintManager.isHardwareDetected() && fingerprintManager.hasEnrolledFingerprints()) {
//                FingerprintManager.AuthenticationCallback authenticationCallback = new FingerprintManager.AuthenticationCallback() {
//                    @Override
//                    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
//                        super.onAuthenticationSucceeded(result);
//                        Toast.makeText(computer.this, "Fingerprint authentication succeeded", Toast.LENGTH_SHORT).show();
//                    }
//
//                    @Override
//                    public void onAuthenticationFailed() {
//                        super.onAuthenticationFailed();
//                        Toast.makeText(computer.this, "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//                    }
//                };
//
//                Cipher cipher = null;
//                try {
//                    cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//                } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//                    e.printStackTrace();
//                }
//
//                FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher);
//
//                fingerprintManager.authenticate(cryptoObject, new CancellationSignal(), 0, authenticationCallback, null);
//            } else {
//                Toast.makeText(computer.this, "Device does not support fingerprint authentication", Toast.LENGTH_SHORT).show();
//            }
//        } else {
//            Toast.makeText(computer.this, "Android version not supported", Toast.LENGTH_SHORT).show();
//        }
//
//        // TODO: Implement fingerprint authentication logic
//        return null;
//    }
//
//
//    private void saveUserData(String id, byte[] fingerprintData) {
//        // TODO: Save user data to Firebase database
//    }
//}
//
//
//
//
//
//
//
//
//









//public class computer extends AppCompatActivity {
//
//    private EditText idEditText;
//    private Button saveButton;
//    private ImageButton fingerprintButton;
//
//    private FingerprintManager fingerprintManager;
//    private KeyguardManager keyguardManager;
//    private String fingerprintData = "myFingerprintData";
////
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_computer);
//
//        idEditText = findViewById(R.id.cmpid);
//        saveButton = findViewById(R.id.savecomp);
//        fingerprintButton = findViewById(R.id.computer);
//
//        fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
//        keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
//
//        // Check if the device has a fingerprint sensor
//        if (fingerprintManager == null || !fingerprintManager.isHardwareDetected()) {
//            // Device does not have a fingerprint sensor, display error message
//            Toast.makeText(this, "Fingerprint sensor not available", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Check if the user has enrolled at least one fingerprint
//        if (!fingerprintManager.hasEnrolledFingerprints()) {
//            // User has not enrolled any fingerprints, display error message
//            Toast.makeText(this, "No fingerprints enrolled", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Check if the user has secured their device with a lock screen
//        if (!keyguardManager.isKeyguardSecure()) {
//            // User has not secured their device with a lock screen, display error message
//            Toast.makeText(this, "Lock screen not set up", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Set up click listener for fingerprint button
//        fingerprintButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                authenticateFingerprint();
//            }
//        });
//
//        // Set up click listener for save button
//        saveButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                saveDataToFirebase();
//            }
//        });
//    }
//
//    private void saveDataToFirebase() {
//    }
//
//    private void authenticateFingerprint() {
//        // Register the user's fingerprint
//        byte[] keyBytes = generateKey(); // TODO: Generate a 128-bit AES key
//        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
//        try {
//            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
//            FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher); // TODO: Replace with actual encryption cipher
//            FingerprintManager.AuthenticationCallback authenticationCallback = new MyAuthenticationCallback(fingerprintData); // Pass fingerprintData to the constructor
//            fingerprintManager.authenticate(cryptoObject, null, 0, authenticationCallback, null);
//        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//            e.printStackTrace();
//        } catch (InvalidKeyException e) {
//            throw new RuntimeException(e);
//        }
//    }
//
//    private byte[] generateKey() {
//        // Generate a 128-bit AES key
//        KeyGenerator keyGenerator;
//        try {
//            keyGenerator = KeyGenerator.getInstance("AES");
//            keyGenerator.init(128);
//            SecretKey secretKey = keyGenerator.generateKey();
//            return secretKey.getEncoded();
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    private class MyAuthenticationCallback extends FingerprintManager.AuthenticationCallback {
//        private String data;
//
//        public MyAuthenticationCallback(String data) {
//            this.data = data;
//        }
//
//        @Override
//        public void onAuthenticationFailed() {
//            super.onAuthenticationFailed();
//            Toast.makeText(computer.this, "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//        }
//
//
//    } else {
//        // Display error message if user input is empty
//        Toast.makeText(computer.this, "Please enter your ID number", Toast.LENGTH_SHORT).show();
//    }
//}
//    });
//
//            // Set up click listener for fingerprint button
//            fingerprintButton.setOnClickListener(new View.OnClickListener() {
//@Override
//public void onClick(View v) {
//        authenticateFingerprint();
//        }
//        });
//        }
//
//private void authenticateFingerprint() {
//        // Register the user's fingerprint
//        byte[] keyBytes = generateKey(); // TODO: Generate a 128-bit AES key
//        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
//        try {
//        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
//        FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher); // TODO: Replace with actual encryption cipher
//        FingerprintManager.AuthenticationCallback authenticationCallback = new MyAuthenticationCallback(fingerprintData); // Pass fingerprintData to the constructor
//        fingerprintManager.authenticate(cryptoObject, null, 0, authenticationCallback, null);
//        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//        e.printStackTrace();
//        } catch (InvalidKeyException e) {
//        throw new RuntimeException(e);
//        }
//        }
//
//private byte[] generateKey() {
//        // Generate a 128-bit AES key
//        KeyGenerator keyGenerator;
//        try {
//        keyGenerator = KeyGenerator.getInstance("AES");
//        keyGenerator.init(128);
//        SecretKey secretKey = keyGenerator.generateKey();
//        return secretKey.getEncoded();
//        } catch (NoSuchAlgorithmException e) {
//        e.printStackTrace();
//        return null;
//        }
//        }
//
//private class MyAuthenticationCallback extends FingerprintManager.AuthenticationCallback {
//    private String data;
//
//    public MyAuthenticationCallback(String data) {
//        this.data = data;
//    }
//
//    @Override
//    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
//        try {
//            // User's fingerprint has been authenticated, save the user's fingerprint data to the database
//            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("userss").child("fingerprintData");
//
//            // Save the user's fingerprint data to the database
//            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid(); // Get the current user's ID
//            byte[] encryptedData = result.getCryptoObject().getCipher().doFinal(data.getBytes()); // Encrypt the fingerprint data using the generated key
//            String encryptedDataString = Base64.encodeToString(encryptedData, Base64.DEFAULT); // Encode the encrypted data as a Base64 string
//
//            // Save the encrypted data to the database under the current user's ID
//            databaseReference.child("users").child(userId).child("fingerprintData").setValue(encryptedDataString);
//
//            Toast.makeText(getApplicationContext(), "Fingerprint authentication succeeded", Toast.LENGTH_SHORT).show();
//        } catch (IllegalBlockSizeException | BadPaddingException e) {
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void onAuthenticationFailed() {
//        Toast.makeText(getApplicationContext(), "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//    }
//}
//



//
//ylgffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
//
//public class LoginActivity extends AppCompatActivity {
//    private EditText idEditText;
//    private Button showButton;
//    private ImageButton fingerprintButton;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login);
//
//        idEditText = findViewById(R.id.idEditText);
//        showButton = findViewById(R.id.showButton);
//        fingerprintButton = findViewById(R.id.fingerprintButton);
//
//        showButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String id = idEditText.getText().toString();
//                byte[] fingerprintData = authenticateFingerprint();
//                showUserData(id, fingerprintData);
//            }
//        });
//
//        fingerprintButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                authenticateFingerprint();
//            }
//        });
//    }
//
//    private byte[] authenticateFingerprint() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
//            if (fingerprintManager != null && fingerprintManager.isHardwareDetected() && fingerprintManager.hasEnrolledFingerprints()) {
//                FingerprintManager.AuthenticationCallback authenticationCallback = new F
//
//
//
//
//                wegeneargow@gmail.com
//                        cont
//                java
//                Copy code
//                FingerprintManager.AuthenticationCallback() {
//                    @Override
//                    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
//                        super.onAuthenticationSucceeded(result);
//                        Toast.makeText(LoginActivity.this, "Fingerprint authentication succeeded", Toast.LENGTH_SHORT).show();
//                    }
//
//                    @Override
//                    public void onAuthenticationFailed() {
//                        super.onAuthenticationFailed();
//                        Toast.makeText(LoginActivity.this, "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//                    }
//                };
//
//                FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(new Cipher());
//
//                fingerprintManager.authenticate(cryptoObject, new CancellationSignal(), 0, authenticationCallback, null);
//            } else {
//                Toast.makeText(LoginActivity.this, "Device does not support fingerprint authentication", Toast.LENGTH_SHORT).show();
//            }
//        } else {
//            Toast.makeText(LoginActivity.this, "Android version not supported", Toast.LENGTH_SHORT).show();
//        }
//
//        // TODO: Implement fingerprint authentication logic
//        return null;
//    }
//
//    private void showUserData(String id, byte[] fingerprintData) {
//        // TODO: Retrieve user data from Firebase database and check against entered id and fingerprint data
//        boolean isAuthorized = checkUserAuthorization(id, fingerprintData);
//
//        if (isAuthorized) {
//            Toast.makeText(LoginActivity.this, "Login succeeded", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private boolean checkUserAuthorization(String id, byte[] fingerprintData) {
//        // TODO: Retrieve user data from Firebase database and check against entered id and fingerprint data
//        return false;
//    }
//}