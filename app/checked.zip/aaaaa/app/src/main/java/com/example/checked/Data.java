package com.example.checked;
public class Data {
    private boolean dormSelected;
    private boolean librarySelected;
    private boolean caffeSelected;
    private boolean securitySelected;
    private String dormInfo;
    private String libraInfo;
    private String caffeInfo;
    private String securInfo;
    private String idInfo;
    private String blockInfo;
    private String dormNumInfo;
    public Data() {
        // Default constructor required for Firebase
    }

    public Data(boolean dormSelected, boolean librarySelected, boolean caffeSelected, boolean securitySelected,
                String dormInfo, String libraInfo, String caffeInfo, String securInfo, String idInfo,
                String blockInfo, String dormNumInfo) {
        this.dormSelected = dormSelected;
        this.librarySelected = librarySelected;
        this.caffeSelected = caffeSelected;
        this.securitySelected = securitySelected;
        this.dormInfo = dormInfo;
        this.libraInfo = libraInfo;
        this.caffeInfo = caffeInfo;
        this.securInfo = securInfo;
        this.idInfo = idInfo;
        this.blockInfo = blockInfo;
        this.dormNumInfo = dormNumInfo;
    }

    public boolean isDormSelected() {
        return dormSelected;
    }

    public boolean isLibrarySelected() {
        return librarySelected;
    }

    public boolean isCaffeSelected() {
        return caffeSelected;
    }

    public boolean isSecuritySelected() {
        return securitySelected;
    }

    public String getDormInfo() {
        return dormInfo;
    }

    public String getLibraInfo() {
        return libraInfo;
    }

    public String getCaffeInfo() {
        return caffeInfo;
    }

    public String getSecurInfo() {
        return securInfo;
    }

    public String getIdInfo() {
        return idInfo;
    }

    public String getBlockInfo() {
        return blockInfo;
    }

    public String getDormNumInfo() {
        return dormNumInfo;
    }

    public void setSecurity(String s) {

    }

    public void setDormInfo(String trim) {
    }

    public void setCaffe(String s) {
    }

    public void setLibraryInfo(String trim) {
    }

    public void setCaffeInfo(String trim) {
    }

    public void setSecurityInfo(String trim) {
    }

    public void setIdInfo(String trim) {
    }

    public void setBlockInfo(String trim) {
    }

    public void setDornumInfo(String trim) {
    }

    public void setLibrary(String s) {
    }

    public void setDorm(String s) {
    }
}