package com.example.checked;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;




import android.Manifest;
import android.content.pm.PackageManager;
import android.text.TextUtils;
        import android.util.Log;
import android.widget.EditText;
        import android.widget.ImageButton;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
        import androidx.core.content.ContextCompat;

        import com.google.android.gms.tasks.OnCompleteListener;
        import com.google.android.gms.tasks.Task;
        import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class letmecheck extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1;

    private FirebaseAuth mAuth;
    private EditText mIdTxt;
    private ImageButton mCameeddBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checme);

        mAuth = FirebaseAuth.getInstance();
        mIdTxt = findViewById(R.id.id);
        mCameeddBtn = findViewById(R.id.scanner);

        mCameeddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission( letmecheck.this, Manifest.permission.CAMERA)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions( letmecheck.this, new String[] { Manifest.permission.CAMERA },
                            CAMERA_PERMISSION_REQUEST_CODE);
                } else {
                    // TODO: Start the device camera and scan the QR code
                    // Once the QR code is scanned, call the fetchAndCompareData method
                }
            }
        });
    }

    private void fetchAndCompareData(String id, String qrCode) {
        if (TextUtils.isEmpty(id)) {
            mIdTxt.setError("Please enter ID");
            mIdTxt.requestFocus();
            return;
        }

        // Get a reference to the Firebase database child node "myinfo"
        DatabaseReference myInfoRef = FirebaseDatabase.getInstance().getReference().child("myinfo");

        // Get a reference to the child node with the given ID in the Firebase database
        DatabaseReference idRef = myInfoRef.child(id);

        idRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists() && snapshot.hasChildren()) {
                    String qrCodeFromDatabase = snapshot.child("qr_code").getValue(String.class);
                    // Check if the QR code matches the value from the device camera
                    if (qrCodeFromDatabase != null && qrCodeFromDatabase.equals(qrCode)) {
                        signInUser();
                    } else {
                        Toast.makeText( letmecheck.this, "You are not authorized", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText( letmecheck.this, "ID not found", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("letmecheck", "Database error: " + error.getMessage());
            }
        });
    }
    private void signInUser() {
        String email = "user@example.com";
        String password = "password";

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information


                            Log.d("letmecheck", "signInWithEmail:success");
                            Toast.makeText( letmecheck.this, "You are authorized", Toast.LENGTH_SHORT).show();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.e("letmecheck", "signInWithEmail:failure", task.getException());
                            Toast.makeText( letmecheck.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // TODO: Start the device camera and scan the QR code
                // Once the QR code is scanned, call the fetchAndCompareData method
            } else {
                Toast.makeText( letmecheck.this, "Camera permission required", Toast.LENGTH_SHORT).show();
            }
        }
    }
}