package com.example.checked;

public class Itemslist {
//    private String Dormitory;
//    private String Library;
//    private String Caffe;
//    private String Dormitary;
//    private String Dormitary;
//    private String Dormitary;

}
