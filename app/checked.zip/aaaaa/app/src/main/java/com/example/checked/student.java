package com.example.checked;
import com.android.volley.Request;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class student extends AppCompatActivity {
    private BiometricPrompt biometricPrompt;
    //private BiometricPrompt.PromptInfo promptInfo;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private Button logout,searchme;
    private DatabaseReference mDatabase;

   // private CheckBox dormCheckBox, libraryCheckBox, caffeCheckBox, securityCheckBox;
    private EditText myidtxt,myinfotxtedy,dormInfoEditText, libraInfoEditText, caffeInfoEditText, securInfoEditText, idInfoEditText, blockInfoEditText, dormNumInfoEditText;
    private Button requestButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_student );

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        logout = findViewById( R.id.logoutbutton );

        logout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                Intent intent = new Intent( student.this, MainActivity.class );
                startActivity( intent );
                Toast.makeText( student.this, "successfully logged out", Toast.LENGTH_LONG ).show();
            }
        } );


        // Initialize Firebase database
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Find views
       // dormCheckBox = findViewById( R.id.Dormitery );
       // libraryCheckBox = findViewById( R.id.Library );
       // caffeCheckBox = findViewById( R.id.Caffe );
       // securityCheckBox = findViewById( R.id.Security );


        dormInfoEditText = findViewById( R.id.DOR );
        libraInfoEditText = findViewById( R.id.libinfo );
        caffeInfoEditText = findViewById( R.id.cofeinfo );
        securInfoEditText = findViewById( R.id.SECURITIINFO );


        idInfoEditText = findViewById( R.id.idinfo );
        blockInfoEditText = findViewById( R.id.blockinfo );
        dormNumInfoEditText = findViewById( R.id.dormnuninfo );

        requestButton = findViewById( R.id.Request );

        // Set button onClickListener
        requestButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Id = idInfoEditText.getText().toString();
                String Dormnum = dormNumInfoEditText.getText().toString();
                String Blocknumber = blockInfoEditText.getText().toString();

                String Dormitory = dormInfoEditText.getText().toString();
                String Library = libraInfoEditText.getText().toString();
                String Caffe = caffeInfoEditText.getText().toString();
                String Security = securInfoEditText.getText().toString();
                if (TextUtils.isEmpty(Id)) {
                    Toast.makeText(student.this, "Id is required", Toast.LENGTH_SHORT).show();
                }
                else {
                    //  boolean Dormitory = dormCheckBox.isChecked();
                    //boolean Library = libraryCheckBox.isChecked();
                    // boolean Security = securityCheckBox.isChecked();
                    //boolean Caffe = caffeCheckBox.isChecked();
                    String key = mDatabase.child( "datas" ).push().getKey();
                    Map<String, Object> datas = new HashMap<>();
                    datas.put( "Dormitory", Dormitory );
                    datas.put( "Library", Library );
                    datas.put( "Security", Security );
                    datas.put( "Caffe", Caffe );
                    datas.put( "Id", Id );
                    datas.put( "Dormnum", Dormnum );
                    datas.put( "Blocknumber", Blocknumber );

                    // give me the android java code that retrieve the the value of  information that contain 7 elements named Dormitory,Library,Caffe,Security,Id,dormnum, and blocknum   into the class named admin.java  from the firebase  with  child named data

//                if (Dormitory) {
//                    data.put( "Dormitory", "Dormitory" );
//                }
//                if (Library) {
//                    data.put( "Library", "Library" );
//                }
//
//                if (Security) {
//                    data.put( "Security", "Security" );
//                }
//
//                if (Caffe) {
//                    data.put( "Caffe", "Caffe" );
//                }
                    mDatabase.child( "datas" ).child( key ).setValue( datas );
                    idInfoEditText.setText( "" );
                    dormNumInfoEditText.setText( "" );
                    blockInfoEditText.setText( "" );

                    dormInfoEditText.setText( "" );
                    libraInfoEditText.setText( "" );
                    caffeInfoEditText.setText( "" );
                    securInfoEditText.setText( "" );

                    // dormCheckBox.setChecked( false );
                    // libraryCheckBox.setChecked( false );
                    //  securityCheckBox.setChecked( false );
                    // caffeCheckBox.setChecked( false );

                    Toast.makeText( student.this, "You are successfully requested", Toast.LENGTH_SHORT ).show();


                }

            }
        } );



        myinfotxtedy = findViewById( R.id.myinfos );
        searchme = findViewById( R.id.searchme );
        myidtxt = findViewById( R.id.myiddd );

        searchme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchid = myidtxt.getText().toString();
//                mDatabase = FirebaseDatabase.getInstance().getReference("data").child(Id);
               // mDatabase = FirebaseDatabase.getInstance().getReference("datas/" + Ids);

                mDatabase.child("datas").orderByChild("Id").equalTo(searchid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            StringBuilder TOTALINFORMATION = new StringBuilder();

                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                String blocknum = dataSnapshot.child( "Blocknumber" ).getValue(String.class);
                                String dormnum = dataSnapshot.child( "Dormnum" ).getValue(String.class);
                                String dormitory = dataSnapshot.child("Dormitory").getValue(String.class);
                                String library = dataSnapshot.child("Library").getValue(String.class);
                                String security = dataSnapshot.child("Security").getValue(String.class);
                                String caffe = dataSnapshot.child("Caffe").getValue(String.class);

                                TOTALINFORMATION.append("Dormnum ").append(dormnum).append("\n")
                                        .append("Blocknumber ").append(blocknum).append("\n")
                                        .append("Dormitory: ").append(dormitory).append("\n")
                                        .append("Library: ").append(library).append("\n")
                                        .append("Security: ").append(security).append("\n")
                                        .append("Caffe: ").append(caffe).append("\n");
                            }

                            myinfotxtedy.setText(TOTALINFORMATION.toString());
                        } else {
                            myinfotxtedy.setText("This Id is not requested ");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("student", "Database Error: " + error.getMessage());
                    }
                });
            }
        });


//
//        // code for the check the finger print information for the pc
//        // Initialize the BiometricPrompt and PromptInfo objects
//        biometricPrompt = new BiometricPrompt(this, new BiometricPrompt.AuthenticationCallback() {
//            @Override
//            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
//                // User's fingerprint has been authenticated, retrieve the user's fingerprint data from the database
//                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("userss").child("fingerprintData");
//                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        // Retrieve the user's fingerprint data and compare it to the authenticated fingerprint
//                        // If the fingerprints match, allow the user to log in
//                        // Otherwise, display an error message
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//                        // Handle database error
//                    }
//                });
//            }
//
//            @Override
//            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
//                // Handle authentication error
//                super.onAuthenticationError(errorCode, errString);
//            }
//
//            @Override
//            public void onAuthenticationFailed() {
//                // User's fingerprint could not be authenticated, display error message
//                Toast.makeText(student.this, "Fingerprint authentication failed", Toast.LENGTH_SHORT).show();
//            }
//        });
//        promptInfo = new BiometricPrompt.PromptInfo.Builder()
//                .setTitle("Authenticate with your fingerprint")
//                .setNegativeButtonText("Cancel")
//                .build();
//
//        // Check if the device has a fingerprint sensor
//        if (!BiometricManager.from(this).canAuthenticate( BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
//            // Device does not have a fingerprint sensor, display error message
//            Toast.makeText(this, "Fingerprint sensor not available", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Show the BiometricPrompt when the user taps the fingerprint image on the screen
//        ImageView fingerprintImage = findViewById(R.id.pressme);
//        fingerprintImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                biometricPrompt.authenticate(promptInfo);
//            }
//        });


    }
}




