package com.example.checked;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class staff extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private Button logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_staff );
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        logout = findViewById( R.id.logoutbutton );

        logout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                Intent intent = new Intent(staff.this,MainActivity.class);
                startActivity( intent );
                Toast.makeText(staff.this,"successfully logedout" ,Toast.LENGTH_LONG ).show();

            }
        } );
    }
}