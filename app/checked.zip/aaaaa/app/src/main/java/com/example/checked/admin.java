package com.example.checked;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;



import com.google.firebase.firestore.FirebaseFirestore;
//public class admin extends AppCompatActivity {
//
//    private FirebaseAuth auth;
//    private FirebaseFirestore db;
//    private Button logout;
//        private DatabaseReference mDatabase;
//        private TableLayout mTableLayout;
//
//        @Override
//        protected void onCreate(Bundle savedInstanceState) {
//                super.onCreate(savedInstanceState);
//                setContentView(R.layout.activity_admin);
//            auth = FirebaseAuth.getInstance();
//            db = FirebaseFirestore.getInstance();
//            logout = findViewById( R.id.logout_button );
//
//            logout.setOnClickListener( new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    auth.signOut();
//                    Intent intent = new Intent( admin.this, MainActivity.class );
//                    startActivity( intent );
//                    Toast.makeText( admin.this, "successfully logged out", Toast.LENGTH_LONG ).show();
//                }
//            } );
//
//
//
//             //   mDatabase = FirebaseDatabase.getInstance().getReference().child("data");
//
//
//            FirebaseDatabase database = FirebaseDatabase.getInstance();
//            DatabaseReference myRef = database.getReference("data");
//
//            myRef.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
//                        boolean Dormitory = ds.child("Dormitory").getValue(Boolean.class);
//                        boolean Library = ds.child("Library").getValue(Boolean.class);
//                        boolean Security = ds.child("Security").getValue(Boolean.class);
//                        boolean Caffe = ds.child("Caffe").getValue(Boolean.class);
//                        String Id = ds.child("Id").getValue(String.class);
//                        String Dormnum = ds.child("Dormnum").getValue(String.class);
//                        String Blocknumber = ds.child("Blocknumber").getValue(String.class);
//
//                        // Concatenate the word "jjjj" to each cell when clicked
//                        // Implement the desired behavior here
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//                    Log.w("Admin", "Failed to read value.", databaseError.toException());
//                }
//            });






import android.content.Context;

import java.util.HashMap;


public class admin extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private Button logout;
    private DatabaseReference mDatabase;
      private TableLayout tableLayout;
    private static final String TAG = "checked";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        logout = findViewById( R.id.logoutbutton );

        logout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                Intent intent = new Intent( admin.this, MainActivity.class );
                startActivity( intent );
                Toast.makeText( admin.this, "successfully logged out", Toast.LENGTH_LONG ).show();
            }
        } );




        tableLayout = findViewById( R.id.tabled );
        FirebaseApp.initializeApp( this );
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference dataRef = database.getReference("datas");

// Attach a listener to the data reference to retrieve the data
        dataRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Clear existing data in the table
                tableLayout.removeAllViews();

                // Create a header row for the table
                TableRow headerRow = new TableRow(getApplicationContext());
                headerRow.setBackgroundColor( Color.parseColor("#808080"));

                TextView idHeader = new TextView(getApplicationContext());
                idHeader.setText("Id_No");
                idHeader.setTextColor(Color.WHITE);
                headerRow.addView(idHeader);
                TextView blockNumHeader = new TextView(getApplicationContext());
                blockNumHeader.setText("Block_No");
                blockNumHeader.setTextColor(Color.WHITE);
                headerRow.addView(blockNumHeader);

                TextView dormNumHeader = new TextView(getApplicationContext());
                dormNumHeader.setText("Dorm_No");
                dormNumHeader.setTextColor(Color.WHITE);
                headerRow.addView(dormNumHeader);



                TextView dormitoryHeader = new TextView(getApplicationContext());
                dormitoryHeader.setText("DormReqest");
                dormitoryHeader.setTextColor(Color.WHITE);
                headerRow.addView(dormitoryHeader);

                TextView libraryHeader = new TextView(getApplicationContext());
                libraryHeader.setText("LibReqest");
                libraryHeader.setTextColor(Color.WHITE);
                headerRow.addView(libraryHeader);

                TextView caffeHeader = new TextView(getApplicationContext());
                caffeHeader.setText("CafReqest");
                caffeHeader.setTextColor(Color.WHITE);
                headerRow.addView(caffeHeader);

                TextView securityHeader = new TextView(getApplicationContext());
                securityHeader.setText("SecReqest");
                securityHeader.setTextColor(Color.WHITE);
                headerRow.addView(securityHeader);


                tableLayout.addView(headerRow);

                // Iterate through the data and add rows to the table
                for (DataSnapshot datas : dataSnapshot.getChildren()) {
//                    HashMap<String,Object> hashMap = (HashMap<String, Object>) dataSnapshot.getValue();

                    String Dormitory = datas.child("Dormitory").getValue(String.class);
                    String Library = datas.child("Library").getValue(String.class);
                    String Caffe = datas.child("Caffe").getValue(String.class);
                    String security = datas.child("Security").getValue(String.class);

                    String id = datas.child("Id").getValue(String.class);
                    String dormNum = datas.child("Dormnum").getValue(String.class);
                    String blockNum = datas.child("Blocknumber").getValue(String.class);



                    TableRow tableRow = new TableRow(getApplicationContext());



                    TextView idValue = new TextView(getApplicationContext());
                    idValue.setText(id);
                    idValue.setPadding(4, 6, 4, 6);
                    tableRow.addView(idValue);

                    TextView blockNumValue = new TextView(getApplicationContext());
                    blockNumValue.setText(blockNum);
                    blockNumValue.setPadding(4, 6, 4, 6);
                    tableRow.addView(blockNumValue);

                    TextView dormNumValue = new TextView(getApplicationContext());
                    dormNumValue.setText(dormNum);
                    dormNumValue.setPadding(4, 6, 4, 6);
                    tableRow.addView(dormNumValue);


                    TextView column1 = new TextView(getApplicationContext());
                    column1.setText(Dormitory);
                    column1.setPadding(6, 6, 6, 6);
                    final DatabaseReference dormitoryRef = datas.getRef().child("Dormitory");
                    column1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView clickedCell = (TextView) view;
                            String originalText = clickedCell.getText().toString();
                            String updatedText = "";
                            if (!originalText.contains(":Cleared")) {
                                updatedText = originalText + ":Cleared";
                                clickedCell.setTextColor(Color.GREEN );

                            } else {
                                updatedText = originalText.replace(":Cleared", "");
                            }
                            clickedCell.setText(updatedText);
                            dormitoryRef.setValue(updatedText);
                        }
                    });
                    tableRow.addView(column1);


                    TextView column2 = new TextView(getApplicationContext());
                    column2.setText(Library);
                    column2.setPadding(6, 6, 6, 6);
                    final DatabaseReference libraryRef = datas.getRef().child("Library");
                    column2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView clickedCell = (TextView) view;
                            String originalText = clickedCell.getText().toString();
                            String updatedText = "";
                            if (!originalText.contains(":Cleared")) {
                                updatedText = originalText + ":Cleared";
                                clickedCell.setTextColor(Color.GREEN );
                            } else {
                                updatedText = originalText.replace(":Cleared", "");
                            }
                            clickedCell.setText(updatedText);
                            libraryRef.setValue(updatedText);
                        }
                    });
                    tableRow.addView(column2);

                    TextView column3 = new TextView(getApplicationContext());
                    column3.setText(Caffe);
                    column3.setPadding(6, 6, 6, 6);
                    final DatabaseReference CaffeRef = datas.getRef().child("Caffe");
                    column3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView clickedCell = (TextView) view;
                            String originalText = clickedCell.getText().toString();
                            String updatedText = "";
                            if (!originalText.contains(":Cleared")) {
                                updatedText = originalText + ":Cleared";
                                clickedCell.setTextColor(Color.WHITE );
                                clickedCell.setBackgroundColor( Color.GREEN );

                            } else {
                                updatedText = originalText.replace(":Cleared", "");
                            }
                            clickedCell.setText(updatedText);
                            CaffeRef.setValue(updatedText);
                        }
                    });
                    tableRow.addView(column3);

                    TextView column4 = new TextView(getApplicationContext());
                    column4.setText(security);
                    column4.setPadding(6, 6, 6, 6);
                    final DatabaseReference SecurityRef = datas.getRef().child("Security");
                    column4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView clickedCell = (TextView) view;
                            String originalText = clickedCell.getText().toString();
                            String updatedText = "";
                            if (!originalText.contains(":Cleared")) {
                                updatedText = originalText + ":Cleared";
                                clickedCell.setTextColor(Color.GREEN );
                            } else {
                                updatedText = originalText.replace(":Cleared", "");
                            }
                            clickedCell.setText(updatedText);
                            SecurityRef.setValue(updatedText);
                        }
                    });
                    tableRow.addView(column4);






                    tableLayout.addView(tableRow);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Database error occurred: " + databaseError.getMessage());
            }
        });
    }
}







//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference dataRef = database.getReference("data");

// Attach a listener to the data reference to retrieve the data
//        dataRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                // Clear existing data in the table
//                tableLayout.removeAllViews();
//
//                // Create a header row for the table
//                TableRow headerRow = new TableRow(getApplicationContext());
//                headerRow.setBackgroundColor(Color.parseColor("#808080"));
//
//                TextView dormitoryHeader = new TextView(getApplicationContext());
//                dormitoryHeader.setText("Dormitory");
//                dormitoryHeader.setTextColor(Color.WHITE);
//                headerRow.addView(dormitoryHeader);
//
//                TextView libraryHeader = new TextView(getApplicationContext());
//                libraryHeader.setText("Library");
//                libraryHeader.setTextColor(Color.WHITE);
//                headerRow.addView(libraryHeader);
//
//                TextView caffeHeader = new TextView(getApplicationContext());
//                caffeHeader.setText("Caffe");
//                caffeHeader.setTextColor(Color.WHITE);
//                headerRow.addView(caffeHeader);
//
//                TextView securityHeader = new TextView(getApplicationContext());
//                securityHeader.setText("Security");
//                securityHeader.setTextColor(Color.WHITE);
//                headerRow.addView(securityHeader);
//
//                TextView idHeader = new TextView(getApplicationContext());
//                idHeader.setText("ID");
//                idHeader.setTextColor(Color.WHITE);
//                headerRow.addView(idHeader);
//                TextView dormNumHeader = new TextView(getApplicationContext());
//                dormNumHeader.setText("Dorm Num");
//                dormNumHeader.setTextColor(Color.WHITE);
//                headerRow.addView(dormNumHeader);
//
//                TextView blockNumHeader = new TextView(getApplicationContext());
//                blockNumHeader.setText("Block Num");
//                blockNumHeader.setTextColor(Color.WHITE);
//                headerRow.addView(blockNumHeader);
//
//                tableLayout.addView(headerRow);
//
//                // Iterate through the data and add rows to the table
//                for (DataSnapshot data : dataSnapshot.getChildren()) {
//                    HashMap<String,Object> hashMap = (HashMap<String, Object>) dataSnapshot.getValue();
//                    String Dormitory = "";
//                    String Library  = "";
//                    String Caffe = "";
//                    if (hashMap.containsKey( "Dormitory" )){
//                        Dormitory = "Dormitory";
//                    }
//                    if (hashMap.containsKey( "Library" )){
//                        Library = "Library";
//                    }
//                    if (hashMap.containsKey( "Caffe" )){
//                        Caffe = "Caffe";
//                    }
//                    TableRow tableRow = new TableRow(getApplicationContext());
//
//                    TextView column1 = new TextView(getApplicationContext());
//                    column1.setText(Dormitory);
//                    column1.setPadding(5, 5, 5, 5);
//                    tableRow.addView(column1);
//
//                    TextView column2 = new TextView(getApplicationContext());
//                    column2.setText(Library);
//                    column2.setPadding(5, 5, 5, 5);
//                    tableRow.addView(column2);
//
//                    TextView column3 = new TextView(getApplicationContext());
//                    column3.setText(Caffe);
//                    column3.setPadding(5, 5, 5, 5);
//                    tableRow.addView(column3);
//
//                    boolean dormitory = data.child("Dormitory").getValue(Boolean.class);
//                    boolean library = data.child("Library").getValue(Boolean.class);
//                    boolean caffe = data.child("Caffe").getValue(Boolean.class);
//                    boolean security = data.child("Security").getValue(Boolean.class);
//
//
//
//
//
//                    String id = data.child("Id").getValue(String.class);
//                    String dormNum = data.child("Dormnum").getValue(String.class);
//                    String blockNum = data.child("Blocknumber").getValue(String.class);
//
//
//
//                   // TableRow tableRow = new TableRow(getApplicationContext());
//
//                    TextView idValue = new TextView(getApplicationContext());
//                    idValue.setText(id);
//                    tableRow.addView(idValue);
//
//                    TextView dormNumValue = new TextView(getApplicationContext());
//                    dormNumValue.setText(dormNum);
//                    tableRow.addView(dormNumValue);
//
//                    TextView blockNumValue = new TextView(getApplicationContext());
//                    blockNumValue.setText(blockNum);
//                    tableRow.addView(blockNumValue);
//
//
//
//
//
//
//                    // Set an onClickListener for each cell in the row
//
//                    for (int i = 0; i < tableRow.getChildCount(); i++) {
//                        final int columnIndex = i;
//                        View cell = tableRow.getChildAt(i);
//                    cell.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
//                                TextView clickedCell = (TextView) view;
//                                String originalText = clickedCell.getText().toString();
//                                String updatedText = "yesss " + originalText; // concatenate "yesss" with the original text
//                                clickedCell.setText(updatedText);
//
//                                // Update the corresponding data in the Firebase database
//                                int rowIndex = tableLayout.indexOfChild(tableRow) - 1; // subtract 1 to exclude the header row
//                                String dataId = dataSnapshot.getChildren().iterator().next().getKey(); // get the ID of the data
//                                DatabaseReference dataToUpdateRef = database.getReference("data").child(dataId).child(String.valueOf(rowIndex));
//
//                                switch (columnIndex) {
//                                    case 0:
//                                        dataToUpdateRef.child("Dormitory").setValue(updatedText);
//                                        break;
//                                    case 1:
//                                        dataToUpdateRef.child("Library").setValue(updatedText);
//                                        break;
//                                    case 2:
//                                        dataToUpdateRef.child("Caffe").setValue(updatedText);
//                                        break;
//                                    case 3:
//                                        dataToUpdateRef.child("Security").setValue(updatedText);
//                                        break;
//                                    case 4:
//                                        dataToUpdateRef.child("Id").setValue(updatedText);
//                                        break;
//                                    case 5:
//                                        dataToUpdateRef.child("Dormnum").setValue(updatedText);
//                                        break;
//                                    case 6:
//                                        dataToUpdateRef.child("Blocknumber").setValue(updatedText);
//                                        break;
//                                }
//                            }
//                        });
//                    }
//
//                    tableLayout.addView(tableRow);
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.e(TAG, "Database error occurred: " + databaseError.getMessage());
//            }
//        });










//              mTableLayout = findViewById(R.id.tabled);
//                mDatabase.addValueEventListener(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                                // clear existing table rows
//                               mTableLayout.removeAllViews();
//
//                                // create table headers
//                                TableRow headerRow = new TableRow(getApplicationContext());
//                                TextView header1 = new TextView(getApplicationContext());
//                                TextView header2 = new TextView(getApplicationContext());
//                                TextView header3 = new TextView(getApplicationContext());
//                                TextView header4 = new TextView(getApplicationContext());
//                                TextView header5 = new TextView(getApplicationContext());
//                                TextView header6 = new TextView(getApplicationContext());
//                                TextView header7 = new TextView(getApplicationContext());
//                                header1.setText("BlkNum");
//                                header2.setText("Caf");
//                                header3.setText("Dorm");
//                                header4.setText("DrmNum");
//                                header5.setText("ID");
//                                header6.setText("Libr");
//                                header7.setText("Secu");
//
//
//
//
//                                headerRow.addView(header1);
//                                headerRow.addView(header2);
//                                headerRow.addView(header3);
//                                headerRow.addView(header4);
//                                headerRow.addView(header5);
//                                headerRow.addView(header6);
//                                headerRow.addView(header7);
//
//                                mTableLayout.addView(headerRow);
//
//                                // create table rows for each data element
//                                for (DataSnapshot data : dataSnapshot.getChildren()) {
//
//                                    String Blocknumber = data.child("Blocknumber").getValue(String.class);
//                                    boolean caffe = data.child("Caffe").getValue(Boolean.class);
//                                    boolean dormitory = data.child("Dormitory").getValue(Boolean.class);
//                                    String Dormnum = data.child("Dormnum").getValue(String.class);
//                                    String Id = data.child("Id").getValue(String.class);
//                                    boolean library = data.child("Library").getValue(Boolean.class);
//                                    boolean security = data.child("Security").getValue(Boolean.class);
//                                        TableRow row = new TableRow(getApplicationContext());
//                                        TextView tv1 = new TextView(getApplicationContext());
//                                        TextView tv2 = new TextView(getApplicationContext());
//                                        TextView tv3 = new TextView(getApplicationContext());
//                                        TextView tv4 = new TextView(getApplicationContext());
//                                        TextView tv5 = new TextView(getApplicationContext());
//                                        TextView tv6 = new TextView(getApplicationContext());
//                                        TextView tv7 = new TextView(getApplicationContext());
//                                    tv1.setText(Blocknumber);
//                                    tv2.setText(String.valueOf(caffe));
//                                    tv3.setText(String.valueOf(dormitory));
//                                    tv4.setText(Dormnum);
//                                    tv5.setText(Id);
//                                    tv6.setText(String.valueOf(library));
//                                    tv7.setText(String.valueOf(security));
//
//                                    //tv2.setText(String.valueOf(caffe));
//
//
//                                        // add click listener to each cell
//                                        tv3.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = dormitory + "fineme";
//                                                        mDatabase.child(data.getKey()).child("Dormitory").setValue(updatedValue);
//                                                        tv3.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv6.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = library + "fineme";
//                                                        mDatabase.child(data.getKey()).child("Library").setValue(updatedValue);
//                                                        tv6.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv2.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = caffe + "fineme";
//                                                        mDatabase.child(data.getKey()).child("Caffe").setValue(updatedValue);
//                                                        tv2.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv7.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = security + "fineme";
//                                                        mDatabase.child(data.getKey()).child("Security").setValue(updatedValue);
//                                                        tv7.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv5.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = Id + "";
//                                                        mDatabase.child(data.getKey()).child("Id").setValue(updatedValue);
//                                                        tv5.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv4.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = Dormnum + "";
//                                                        mDatabase.child(data.getKey()).child("Dormnum").setValue(updatedValue);
//                                                        tv4.setText(updatedValue);
//                                                }
//                                        });
//
//                                        tv1.setOnClickListener(new View.OnClickListener() {
//                                                @Override
//                                                public void onClick(View v) {
//                                                        String updatedValue = Blocknumber + "";
//                                                        mDatabase.child(data.getKey()).child("Blocknumber").setValue(updatedValue);
//                                                        tv1.setText(updatedValue);
//                                                }
//                                        });
//
//                                        row.addView(tv1);
//                                        row.addView(tv2);
//                                        row.addView(tv3);
//                                        row.addView(tv4);
//                                        row.addView(tv5);
//                                        row.addView(tv6);
//                                        row.addView(tv7);
//                                        mTableLayout.addView(row);
//                                }
//                        }
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError databaseError) {
//                              // Intent intent = new Intent(admin.this,admin.class);
//                               Log.e("admin", "Error retrieving data from Firebase", databaseError.toException());
//                        }
//                });

