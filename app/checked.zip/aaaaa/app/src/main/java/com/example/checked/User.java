package com.example.checked;

public class User {
    private String userId;
    private String ids;
    private String name;
    private String email;
    private String selectedUserType;
    private String dept;

    public User(String userId, String ids, String name, String email, String selectedUserType, String dept) {
        this.userId = userId;
        this.ids = ids;
        this.name = name;
        this.email = email;
        this.selectedUserType = selectedUserType;
        this.dept = dept;
    }

    // getter and setter methods for the fields
}
